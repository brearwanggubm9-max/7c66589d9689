// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Tonemap HDR scene"); }
int main(){
  announce();
  return lionss_run_workload("hdr-tonemap");
}
