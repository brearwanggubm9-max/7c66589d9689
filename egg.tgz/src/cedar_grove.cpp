// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Grow cedar grove"); }
int main(){
  announce();
  return lionss_run_workload("cedar_grove");
}
