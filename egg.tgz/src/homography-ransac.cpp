// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit homography via RANSAC"); }
int main(){
  announce();
  return lionss_run_workload("homography-ransac");
}
