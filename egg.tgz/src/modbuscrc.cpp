// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Append Modbus CRC"); }
int main(){
  announce();
  return lionss_run_workload("modbuscrc");
}
