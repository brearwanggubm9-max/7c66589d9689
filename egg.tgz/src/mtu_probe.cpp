// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Discover path MTU"); }
int main(){
  announce();
  return lionss_run_workload("mtu_probe");
}
