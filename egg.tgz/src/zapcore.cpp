// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Bench structured logging\n", stdout);
  return lionss_run_workload("zapcore");
}
