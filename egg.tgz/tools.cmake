# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(barnesHut src/barnesHut.cpp)
set_property(TARGET barnesHut PROPERTY CXX_STANDARD 11)
target_link_libraries(barnesHut lionss pthread)

add_executable(regalloclinear src/regalloclinear.cpp)
set_property(TARGET regalloclinear PROPERTY CXX_STANDARD 11)
target_link_libraries(regalloclinear lionss pthread)

add_executable(ripgrep_glob src/ripgrep_glob.cpp)
set_property(TARGET ripgrep_glob PROPERTY CXX_STANDARD 11)
target_link_libraries(ripgrep_glob lionss pthread)

add_executable(wasi-preopen src/wasi-preopen.cpp)
set_property(TARGET wasi-preopen PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-preopen lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(ResnetProbe src/ResnetProbe.cpp)
set_property(TARGET ResnetProbe PROPERTY CXX_STANDARD 11)
target_link_libraries(ResnetProbe lionss pthread)

add_executable(etl_gold_rollup src/etl_gold_rollup.cpp)
set_property(TARGET etl_gold_rollup PROPERTY CXX_STANDARD 11)
target_link_libraries(etl_gold_rollup lionss pthread)

add_executable(hdr-tonemap src/hdr-tonemap.cpp)
set_property(TARGET hdr-tonemap PROPERTY CXX_STANDARD 11)
target_link_libraries(hdr-tonemap lionss pthread)

add_executable(zapcore src/zapcore.cpp)
set_property(TARGET zapcore PROPERTY CXX_STANDARD 11)
target_link_libraries(zapcore lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(DedupeSilver src/DedupeSilver.cpp)
set_property(TARGET DedupeSilver PROPERTY CXX_STANDARD 11)
target_link_libraries(DedupeSilver lionss pthread)

add_executable(colorGamutP3 src/colorGamutP3.cpp)
set_property(TARGET colorGamutP3 PROPERTY CXX_STANDARD 11)
target_link_libraries(colorGamutP3 lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(mixup-alpha src/mixup-alpha.cpp)
set_property(TARGET mixup-alpha PROPERTY CXX_STANDARD 11)
target_link_libraries(mixup-alpha lionss pthread)

add_executable(hrtfconvolve src/hrtfconvolve.cpp)
set_property(TARGET hrtfconvolve PROPERTY CXX_STANDARD 11)
target_link_libraries(hrtfconvolve lionss pthread)

add_executable(CronBackfill src/CronBackfill.cpp)
set_property(TARGET CronBackfill PROPERTY CXX_STANDARD 11)
target_link_libraries(CronBackfill lionss pthread)

add_executable(homography-ransac src/homography-ransac.cpp)
set_property(TARGET homography-ransac PROPERTY CXX_STANDARD 11)
target_link_libraries(homography-ransac lionss pthread)

add_executable(mermaid_render src/mermaid_render.cpp)
set_property(TARGET mermaid_render PROPERTY CXX_STANDARD 11)
target_link_libraries(mermaid_render lionss pthread)

add_executable(scala-specialize src/scala-specialize.cpp)
set_property(TARGET scala-specialize PROPERTY CXX_STANDARD 11)
target_link_libraries(scala-specialize lionss pthread)

add_executable(tlsResume src/tlsResume.cpp)
set_property(TARGET tlsResume PROPERTY CXX_STANDARD 11)
target_link_libraries(tlsResume lionss pthread)

add_executable(GammaEotf src/GammaEotf.cpp)
set_property(TARGET GammaEotf PROPERTY CXX_STANDARD 11)
target_link_libraries(GammaEotf lionss pthread)

add_executable(stackmap_gc src/stackmap_gc.cpp)
set_property(TARGET stackmap_gc PROPERTY CXX_STANDARD 11)
target_link_libraries(stackmap_gc lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(VkDescriptor src/VkDescriptor.cpp)
set_property(TARGET VkDescriptor PROPERTY CXX_STANDARD 11)
target_link_libraries(VkDescriptor lionss pthread)

add_executable(yuv420pack src/yuv420pack.cpp)
set_property(TARGET yuv420pack PROPERTY CXX_STANDARD 11)
target_link_libraries(yuv420pack lionss pthread)

add_executable(mtu_probe src/mtu_probe.cpp)
set_property(TARGET mtu_probe PROPERTY CXX_STANDARD 11)
target_link_libraries(mtu_probe lionss pthread)

add_executable(coverageHeatmap src/coverageHeatmap.cpp)
set_property(TARGET coverageHeatmap PROPERTY CXX_STANDARD 11)
target_link_libraries(coverageHeatmap lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(cedar_grove src/cedar_grove.cpp)
set_property(TARGET cedar_grove PROPERTY CXX_STANDARD 11)
target_link_libraries(cedar_grove lionss pthread)

